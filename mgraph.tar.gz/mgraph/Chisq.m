function result=Chisq(x,n)

while 1 
    if n==1 & x>1000
      result= 0;
      break;
    end
    
    if x>1000 | n>1000   
        q=Chisq((x-n).*(x-n)./(2.*n),1)./2;
      
        if x>n 
          result=q;
          break;
        else
          result=1-q;
          break;
        end
    end
    
    p=exp(-0.5.*x); 
    if mod(n,2)==1 
       p=p.*sqrt(2.*x./pi);
    end
    k=n; 
    while k>=2 
        p=p.*x./k; 
        k=k-2;
    end
    t=p; 
    a=n; 
    while t>0.0000000001.*p
        a=a+2; 
        t=t.*x./a; 
        p=p+t;
    end;
    result=1-p;
    break;
end
