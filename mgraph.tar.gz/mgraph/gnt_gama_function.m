function gama=gnt_gama_function(x)
%compute the gama function
if x==1
    gama=1;
else
    gama=x*gnt_gama_function(x);
end