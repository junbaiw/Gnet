function is_SDordering=MGraph_isSDordering(input_k_cliques)
%test function of SD-ordering
%in current function did not include mixed model (discrite and continues data)
%Input: graph model cliques, set in cell string
%Output: 1 is the decomposable model
%		   0 is not the decomposable model
%clear all
%graph has k cliques
%input_k_cliques={ '1 2' ; '2 4'; '1 3'; '3 4'} %no
%input_k_cliques={ '1 2' ; '1 3'; '2 3' } %no
%input_k_cliques={ '1 2 3' ; '2 3 4' } %yes
%input_k_cliques={'1 2 5' ; '1 3 5'; '2 4 5';' 3 4 5 ' } %no
%input_k_cliques={'1 2' ; '1 3'; '2 4 5';' 3 5' } %no
%input_k_cliques={ '1 2 3 '} %yes
%input_k_cliques={ '1 2';'2 3';'3 4';'1 4'} % no 
%input_k_cliques={ '1 2 4 '; ' 2 3 4'} %yes
%input_k_cliques={ '1 2 '; ' 2 3 '} %yes
%input_k_cliques={ '1 2 3 '; '1 2 5 ';'1 3 4';'1 4 5'} %no
%input_k_cliques={ '1  '; ' 2 3 '} %yes





%make k-1 intersection sets
lnof_k_cliques=size(input_k_cliques,1);
for i=2:lnof_k_cliques
   if i==2
      tempB=intersect(str2num(strvcat(input_k_cliques{i})),str2num(strvcat(input_k_cliques{i-1})));
      if ~isempty(tempB)
         intersection_setsB{i}=num2str(tempB);
      else
         intersection_setsB{i}=tempB;
      end
   else
      temp_unionOfC=[]; %{};
      for j=1:i-1
	temp_unionOfC=union(temp_unionOfC,str2num(strvcat(input_k_cliques{j})));
      end
      tempB=intersect(str2num(strvcat(input_k_cliques{i})),temp_unionOfC);
      if ~isempty(tempB)
         intersection_setsB{i}=num2str(tempB);
      else
         intersection_setsB{i}=tempB;
      end
   end
end   
clear tempB
%search sth intersection sets whether contained in jth cliques, j<s
%if yes, continue, if no then stop 
isAmemberOfC=[];
for s=2:lnof_k_cliques
   tempB=intersection_setsB{s};
   if isempty(tempB)
      isAmemberOfC(s-1)=1;
   else
      isAmemberOfC(s-1)=0;
  	  for j=1:s-1
     	 if ismember(str2num(strvcat(tempB)),str2num(strvcat(input_k_cliques{j})))
       	  isAmemberOfC(s-1)=1;
      	 end
   	  end
   end
end

%if one of the b sets not conained in C
if isempty(find(isAmemberOfC==0))
   is_SDordering=1; %decomposable model
else
   is_SDordering=0;   %nondecomposable model
end

%is_SDordering   


