function new_out=MGraph_loglineMergeEdge(i,removeEG,testdata,out)
%make new partiation of raw data based on new model of the data
%idxof_remove,removeEG,sread,numofGin_X,string_name,testdata,columnStart,out,roworcolumn)
%i=1;
newmodel_EG=removeEG.new_model{i};
fullmodel_EG=out.labelof_Gp;
delete_EG=setdiff(fullmodel_EG,newmodel_EG);
lnof_deletEG=length(delete_EG);
lnof_Gp=length(out.orderof_Gp);
%%%%
labelof_Gp=out.labelof_Gp; %updata
startnumof_Col=out.startnumof_Col; %updata
groupidx=out.groupidx; %updata
old_testdata=testdata; %updata
numoftype_ineachGp=out.numoftype_ineachGp; %updata
orderof_Gp=out.orderof_Gp; %updata


for k=1:lnof_deletEG
    temp_deletEG=delete_EG(k);
    idxof_remove=findstr(temp_deletEG,labelof_Gp);
    %it's for column
    if idxof_remove>=startnumof_Col
        if idxof_remove~=lnof_Gp
            gp_idx=idxof_remove;
            tij=groupidx{gp_idx};
            numoftype_inGp=numoftype_ineachGp(gp_idx);
            %bug at here nov 12.2002
            [rowof_tij,colof_tij]=size(tij);
            numoftype_inGp;
            ini_gi=1;
            intval_gi=rowof_tij/numoftype_inGp;
            fixed_intval=intval_gi;
            testdata2=0;
            for gi=1:numoftype_inGp
            	i=tij(ini_gi:intval_gi,:);
            	%j=tij(rowof_tij/numoftype_inGp+1:rowof_tij,:)
               testdata2=testdata2+old_testdata(:,i');  %+old_testdata(:,j');
               ini_gi=ini_gi+fixed_intval;
               intval_gi=intval_gi+fixed_intval;
           end
             newdata=testdata2;
        else %for last group if it is column
            gp_idx=idxof_remove;
            tij=groupidx{gp_idx};
            tij=sort(tij); %need check ,it has bug
            numoftype=numoftype_ineachGp(gp_idx);
            ln_gpIdx=size(tij);
            i_idx=1:numoftype:ln_gpIdx(1);
            j_idx=2:numoftype:ln_gpIdx(1);
            size_tij=size(tij);
            real_i=tij(i_idx);
            real_j=tij(j_idx);
            testdata3=old_testdata(:,real_i)+old_testdata(:,real_j);
            newdata=testdata3;
        end    
    elseif idxof_remove<startnumof_Col
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %it's for row 
        gp_idx=idxof_remove;
        tij=groupidx{gp_idx};
        numoftype=numoftype_ineachGp(gp_idx);
        %if numoftype==2
            tij=sort(tij);
            ln_gpIdx=size(tij);
            i_idx=1:numoftype:ln_gpIdx(1);
            j_idx=2:numoftype:ln_gpIdx(1);
            size_tij=size(tij);
            if size(tij(i_idx,:)',1)>1 & size(tij(i_idx,:)',2)>1
                real_i=reshape(tij(i_idx,:)',1,ln_gpIdx(1));
            else
                 real_i=tij(i_idx,:);
            end
            if  size(tij(j_idx,:)',1)>1 & size(tij(j_idx,:)',2)>1
                real_j=reshape(tij(j_idx,:)',1,ln_gpIdx(1));
            else
                real_j=tij(j_idx,:);
            end
            testdata3=old_testdata(real_i,:)+old_testdata(real_j,:);
            %else
           % disp('Check!')
            %end
        newdata=testdata3;
    end
    old_testdata=newdata;
   
    numofGin_idx=1:length(numoftype_ineachGp);
    new_numofGin_idx=setdiff(numofGin_idx,gp_idx);
    new_numofGin_X=numoftype_ineachGp(new_numofGin_idx);
    numoftype_ineachGp=new_numofGin_X;
    
    new_string_name=labelof_Gp(new_numofGin_idx);
    labelof_Gp=new_string_name;
    
    temp_sread=orderof_Gp(gp_idx);
    idx=1;
    new_sread=[];
    for i=1:length(orderof_Gp)
        if orderof_Gp(i)<temp_sread
            new_sread(idx)=orderof_Gp(i);
            idx=idx+1;
        elseif orderof_Gp(i)>temp_sread
           new_sread(idx)=orderof_Gp(i)-1;
            idx=idx+1;
        end
    end
    %orderof_Gp=orderof_Gp(new_numofGin_idx);
    orderof_Gp=new_sread;
    
    if gp_idx<startnumof_Col
        new_columnStart=startnumof_Col-1;
    else
        new_columnStart=startnumof_Col;
    end
    startnumof_Col=new_columnStart;
    
    tempresult=MGraph_loglineMakeTableIndex(numoftype_ineachGp,size(old_testdata),length(labelof_Gp),orderof_Gp,startnumof_Col,old_testdata);
    groupidx=tempresult.groupidx;
end %end all

new_out.labelof_Gp=labelof_Gp; %updata
new_out.startnumof_Col=startnumof_Col; %updata
new_out.groupidx=groupidx; %updata
new_out.testdata=old_testdata; %updata
new_out.numoftype_ineachGp=numoftype_ineachGp; %updata
new_out.orderof_Gp=orderof_Gp; %updata
