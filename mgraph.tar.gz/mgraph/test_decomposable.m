q=40
oldModel=MGraph_num2string(1:q);
temp_newModel=oldModel;
delet_edge_location=[3,2];
delet_edge_string=MGraph_num2string(delet_edge_location);
new_model=MGraph_makeSubGraph(temp_newModel,delet_edge_string);

for new_idx=1:length(new_model)
          		numberVector{new_idx}=num2str(MGraph_string2num(new_model(new_idx)));
end
input_k_cliques=(numberVector)';
is_SDordering=MGraph_isSDordering(input_k_cliques);


%test graph
G=[  0     1     1     0     0;...
     0     0     1     0     0;...
     0     0     0     1     1;...
     0     0     0     0     1;...
     0     0     0     0     0]
     

%add edge and make a new graph
old_model=eye(5,5)
add_edge_location=[1 2]
old_model(add_edge_location(1),add_edge_location(2))=1
old_model(add_edge_location(2),add_edge_location(1))=1
up_old_model=triu(old_model)
[xi yj]=find(up_old_model)


%find where need add edge
old_model={[1 2]; [1 3]; 4; 5}

old_model={[1 2 3 4]; 5};
old_model={[1 2 3];4 ;5}
%add_edge=[1 2]


clear all
old_model={1 2 3 4 5};
%old_model={[1  3 4];[1 2] ;[2 5]}
while 1

add_edge=str2num(input('add edge ','s'))

len_of_vertices=length(old_model);
idx=1;
n_idx=1;
need_check_model=[];
for i=1:len_of_vertices
    temp_sub=old_model{i};
    temp_ismember=ismember(temp_sub,add_edge);
    if  (~isempty(find(temp_ismember==1)) &length(temp_sub)<length(add_edge))
        %we find the location
        need_check_model{n_idx}=temp_sub;
        n_idx=n_idx+1;
    else
        %keep old edge
        new_model{idx}=temp_sub;
        idx=idx+1;
    end
end
%add new edge
new_model{idx}=add_edge;
add_edge_idx=idx;

%check need check the edges
if ~isempty(need_check_model)
    len_of_check=length(need_check_model);
    for i=1:len_of_check
        for j=1:idx
            inter_member=intersect(need_check_model{i},new_model{j});
            %delete subset which alread included in new_model
            if ~ismember(inter_member,new_model{add_edge_idx})
                idx=idx+1;
                new_model{idx}=need_check_model{i};
            end
        end
    end
end %end need check
idx_of_new_model=1:idx;
%check complete clique, newly add the edges shared same neighbors BUG at here!!!
nb_idx=1;
shared_neighbor=[];
for i=1:idx
    if i~=add_edge_idx
       %find neighbor of add_edges
       tempnb1=intersect(add_edge(1),new_model{i});
       if ~isempty(tempnb1)
           shared_neighbor{nb_idx}=setdiff(new_model{i},add_edge(1));
           idx_of_neighbor(nb_idx)=i;
           nb_idx=nb_idx+1;
       end
       tempnb2=intersect(add_edge(2),new_model{i});
       if ~isempty(tempnb2)
           shared_neighbor{nb_idx}=setdiff(new_model{i},add_edge(2));
           idx_of_neighbor(nb_idx)=i;
           nb_idx=nb_idx+1;
        end
    end
end
%check whether did they shared same neighbor if yes, combibe them togehter bug here??
%if length(shared_neighbor)>1
%    sameneighbor=shared_neighbor{1};
%    %all neighbor should be same??
%    for i=1:nb_idx-2
%        sameneighbor=intersect(sameneighbor,shared_neighbor{i+1});
%    end
%else
%    sameneighbor=[];
%end
sameneighbor{1}=[];
sam_idx=1;
for i=1:nb_idx-1
    for j=i+1:nb_idx-1
        isdiff=setdiff(shared_neighbor{i},shared_neighbor{j});
        if isempty(isdiff) 
            if ~isempty(setdiff(shared_neighbor{j},sameneighbor{end}))
                sameneighbor{sam_idx}=shared_neighbor{j};
                sam_idx=sam_idx+1;
            end
        end
    end
end

temp_model=[];
idx2_of_new_model=idx_of_new_model;
model_idx=1;
new_model2={};
if ~isempty(sameneighbor)
    %combine the commone edge with added edge together make a new model
    if length(sameneighbor)>1
        errordlg('Something wrong at here!please check!!!');
        break;
    else
        new_model{add_edge_idx}=union(sameneighbor{1},add_edge);
    end
    %then check whehter any old model included in this new model , if yes. delet it
    for i=1:length(new_model)
       if i~=add_edge_idx
            sub_member=intersect(new_model{add_edge_idx},new_model{i})
            %delete subset which alread included in new_model
            if sum(~ismember(sub_member,new_model{add_edge_idx})) 
                new_model2{model_idx}=new_model{i};
                model_idx=model_idx+1;
            elseif (sum(ismember(sub_member,new_model{add_edge_idx})) & length(new_model{i})>=length(new_model{add_edge_idx}))
                new_model2{model_idx}=new_model{i};
                model_idx=model_idx+1;
            elseif isempty(sub_member)
                new_model2{model_idx}=new_model{i};
                model_idx=model_idx+1;
            elseif length(sub_member)<2
                new_model2{model_idx}=new_model{i};
                model_idx=model_idx+1;
            end
        elseif i==add_edge_idx
            new_model2{model_idx}=new_model{i};
        end
    end %end for
else
    for i=1:length(idx2_of_new_model)
        new_model2{i}=new_model{idx2_of_new_model(i)};
    end
end

old_model=new_model2
new_model=[];
need_check_model=[];
shared_neighbor=[];

end









% for i=1:length(idx_of_neighbor)+1
   %     if i<=length(idx_of_neighbor)
   %         temp_model=union(new_model{idx_of_neighbor(i)},temp_model);
   %         idx2_of_new_model=setdiff(idx2_of_new_model,idx_of_neighbor(i));
   %     else
   %         temp_model=union(new_model{add_edge_idx(1)},temp_model);
   %         idx2_of_new_model=setdiff(idx2_of_new_model,add_edge_idx);
   %     end
   % end
   

   
   
   %new_model2={};
%if ~isempty(temp_model)
%    new_model2{1}=temp_model;
%    for i=1:length(idx2_of_new_model)
%        new_model2{1+i}=new_model{idx2_of_new_model(i)};
%    end
%else
%     for i=1:length(idx2_of_new_model)
%        new_model2{i}=new_model{idx2_of_new_model(i)};
%    end
%end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%test 2
clear all
%old_model={[1 3 ];[5 4 3] ;[1 2]}
old_model={[1 2 3];[1 3 4];[3 4 5];[2 3 5]}
%old_model={1 2 3 4 5}
while 1

add_edge=str2num(input('add edge ','s'))

len_of_vertices=length(old_model);
new_model=old_model;
%add new edge
new_model{len_of_vertices+1}=add_edge;

%try to find the clique in the graph
%do they have a path from add_edge_(1) to add_edge(2) other than add_edge
loop=1;
adjecent_edges=[];
visited_idx=0;
record_idx=0;
while loop<len_of_vertices+1
    %search all the subset noinclude the newly added edges
    start_location=loop;
    [diffV ,adjecentV]=test_adjecent_edge2(len_of_vertices,new_model,add_edge,start_location)
    
    %[add_edge1 ,adjecentV,record_idx]=test_adjecent_edge(len_of_vertices,new_model,add_edge1,visited_idx,add_edge2);
    adjecent_edges{loop}=adjecentV;
    loop=loop+1;
    
end

%we fint a path with minumn length
total_idx=1;
all_path=[];
 for i=1:length(adjecent_edges)
    temp1=[];
    temp_idx=1;
    temp_adjecent=[];
     if ~isempty(adjecent_edges{i})
        temp1=adjecent_edges{i};
        len_temp1=length(temp1);
        for j=1:len_temp1
            if ~isempty(temp1(j))
                temp_adjecent=[temp_adjecent temp1{j}];
            end
        end
        all_path{total_idx}=temp_adjecent;
        all_path_length(total_idx)=length(temp_adjecent);
        total_idx=total_idx+1;
    end
end

if ~isempty(all_path) 
    [sort_allpath_length,idx_sort]=sort(all_path_length);
    for i=1:length(all_path_length)
        if sort_allpath_length(i)>2
            ml_idx=idx_sort(i);
            ml=sort_allpath_length(i);
            min_path=[all_path{ml_idx}];
            if (length(min_path)>2 & sum(ismember(add_edge,min_path))==length(add_edge))
                new_model{end+1}=min_path;    
            end
        end
    end
end

%Then check does any subset is included in newly added the model
len_of_model=length(new_model)
new_model{len_of_model}=unique(new_model{len_of_model});
%last one always is the newly added one
new_model2={};
ii=1;
for i=1:len_of_model-1
    diffV=setdiff(new_model{i},new_model{len_of_model});
    if ~isempty(diffV)
        new_model2{ii}=new_model{i};
        ii=ii+1;
    end
end
%added the new model
new_model2{end+1}=new_model{end};

new_model={};
old_model={};
old_model=new_model2

end











