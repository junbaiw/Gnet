function new_model3=MGraph_makeSubGraph(oldmodel,delet_edge)
%INPUT: oldmodel cliques, delet_edge
%OUTPUT: newmodel after delet need deleted edge
%it is in string sets, cell array
%make sub new model , based on old model and input deleted new edge
%and check any newly created model is not containd inside of other models
%clear all
%oldmodel={'ABC','ABD','ED','AE','BE'}
%delet_edge={'AB'}

%oldmodel={'ACDEF','ABCEF'}
%delet_edge={'CD'}

%oldmodel={'ADEF','ACEF','ABCF'};
%delet_edge={'DF'}

%oldmodel={'ADE','ACE','ABC','ABF'}
%delet_edge={'AF'}


%oldmodel={'ABCDE','BCDEF'}
%delet_edge={'EA'}

%oldmodel={ 'ABC'   , 'BCD'    ,'CDE'  ,  'DEF'}
%delet_edge={'EC'}


%oldmodel=sort(oldmodel); 
%in gaussian model it can not be sorted
%
record_idx=[];
new_idx=[];
old_idx=[];
delet_record_idx=[];
idx=1;
delet_edgeStr=strvcat(delet_edge);
for i=1:length(oldmodel)
   %first find where the model need separate
   tempM=strvcat(oldmodel{i});
   if sum(ismember(strvcat(delet_edge),tempM))==2 %edge need be separated at here
    	  tempModel1=setdiff(tempM,(delet_edgeStr(1)));
         tempModel2=setdiff(tempM,(delet_edgeStr(2)));
         new_model{idx}=tempModel1;
         record_idx(end+1)=idx;
         idx=idx+1;
         new_model{idx}=tempModel2;
         record_idx(end+1)=idx;
         idx=idx+1;
   else
      new_model{idx}=tempM;
      idx=idx+1;
   end   
end

%test the new subgroup whether included in one of the old group
%if yes delete the new one and keep the old one
iid=1;
for i=1:length(record_idx)
   tempnewModel=(new_model{record_idx(i)}); %get new sub model
   tempOldModel=setdiff(new_model,tempnewModel); %get all model except above new one
   isfound=0;
   for j=1:length(tempOldModel)
      if sum(ismember(strvcat(tempnewModel),strvcat(tempOldModel{j})))==length(tempnewModel) %find new model is contained in old one
         %then remove it from new model
         isfound=1;
      end
   end
   if isfound==1
      delet_record_idx(iid)=record_idx(i);
      iid=iid+1;
   end
end


%remove need deleted the new model bug here 12.05
old_idx=1:size(new_model,2);
new_idx=setdiff(old_idx,delet_record_idx);
for i=1:length(new_idx)
   new_model2{i}=new_model{new_idx(i)};
end

%remove empty models added sep 2006
loop=1;
for i=1:length(new_model2)
   if ~isempty(new_model2{i})
       new_model3{loop}=new_model2{i};
       loop=loop+1;
   end
end
