function [color,time,d,f,phi,back_edge]=dfs(G)
%Depth-first search of the graph
%Input : adjecent matrix of Graph
%Output: d time, f time and predecessor of each vertex phi or tree edges
%
[row col]=size(G);
for u=1:row
    color(u)=0;
    %white color 0 for each vertex i
    phi{u}=-1;
    %assign vertex i 's predecessor is nil
end
time=0;
d=[];
time=0;
f=[];
idx=1;
back_edge=[];

for u=1:row
    tree_u=[];
    if color(u)==0
        %search vertex i
        [color,time,d,f,phi,idx,back_edge]=dfs_visit(G,u,color,time,d,f,phi,idx,back_edge);           
    end
    
end

