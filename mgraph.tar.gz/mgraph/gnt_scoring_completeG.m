function [cond_density,T0,TL]=gnt_scoring_completeG(u0,v,b,sigma,alpha,n,L,d,tempG)
%Input: u0 is estimated mean, v is estimated variance, b is the regression coefficient, 
%sigma is effective size of mean, alpha is effective size of variance, 
%n is number of variable, L is number of casesm, d is obsearcations.
%Only b in cell structure
%Initial graph can not use empty graph to calculate the complete G score??
%Output: conditinal density of complete network

%compute precise matrix
w=gnt_make_precision_matrix(v,b);
%compute initial precise matrix
T0=w^(-1)*sigma*(alpha-n-1)/(sigma+1);
%compute sample mean
XL=mean(d);
%update sample mean
uL=(sigma*u0+L*XL)/(sigma+L);
%update sample varianc
rep_XL=repmat(XL,L,1);
SL=(d-rep_XL)'*(d-rep_XL);
%update precise matrix
TL=T0+SL+(sigma*L)/(sigma+L)*(u0-XL)'*(u0-XL);
cond_density=(gnt_conditional_density(n,L,sigma,alpha,T0,TL));
%added jbw 10_04
%n,L,tempG,sum(sum(abs(tempG)))
%pause
%mod_d=sum(sum(abs(tempG)));
%mod_r=n;
%mod_n=L;
% penitent/penalize the complexity of model size
%cond_density=cond_density- 1/2*mod_d*log10(mod_n);
