function marray_debuge(str)
global table
disp(str);
[row,column]=size(str);
for i=1:row
	dsp1=sprintf('%s',str(i,:));
	size_table=size(table);
	table{size_table(1)+1,1}=dsp1;
end