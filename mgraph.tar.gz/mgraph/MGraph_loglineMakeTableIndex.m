function result=MGraph_logloneMakeTableIndex(numofGin_X,size_data,numofVar,sread,columnStart,testdata)
%Input: numofGin_X: number of subtypes in each group
%   size_data: size of data 
%   numofVar: number of variables
%   sread: order of data. it start from the highest level of row then from highest level
%   of column

%
%test data 1
%initial number
%numofGin_X(1)=2
%numofGin_X(2)=2
%numofGin_X(3)=2
%numofGin_X(4)=2
%numofGin_X(5)=2
%numofGin_X(6)=2
%sread=[1,2,3,4,5,6]
%size_data=[16,4]; %size(testdata)
%numof_row=16; %size_data(1)
%numof_col=4; % size_data(2)
%numofVar=6; %4
%numof_Gnum=16 %4
%clear temp temp2 group1 group2

%test data2
%initial number
%numofGin_X(1)=3
%numofGin_X(2)=2
%numofGin_X(3)=2
%numofGin_X(4)=2
%numofGin_X(5)=3
%sread=[1,2,3,4,5]
%size_data=[12,6]; %size(testdata)
%numof_row=12; %size_data(1)
%numof_col=6; % size_data(2)
%numofVar=5; %4
%numof_Gnum=12 %4
%%%
%test
%
%numofGin_X=numoftype_ineachGp;
%size_data=size(old_testdata);
%numofVar=length(labelof_Gp);
%sread=orderof_Gp;
%columnStart=startnumof_Col;

%test
%numofGin_X,size_data,numofVar,sread,columnStart
%end test

numof_row=size_data(1);
numof_col=size_data(2);
%numof_Gnum=numof_Var;
startnumof_ColGp=[];
group=[]; %added sep 2006

clear temp temp2 group1 group2
%Make the table for the input data
isfirst=1; %first time start the column data
for i=1:numofVar
    temp_Gnum=numof_row/numofGin_X(i); %number of elements in each subgroups
    idx=1;
    if (temp_Gnum>=1 & i<columnStart) %before finished row partition 
      if i==1 %initial first level of groups
        for j=1:temp_Gnum:numof_row
           temp(:,:,idx)=j:j+temp_Gnum-1;
           eval(['group',num2str(i),'(idx,:)=temp(:,:,idx);']);
           idx=idx+1;
        end
        numof_row=temp_Gnum; %number of row in each subgroups
        temp=group1;
        eval(['group{i}=temp;']);
        numof_subG=idx-1; %number of subgroups
     else % start rest of level groups
        for j=1:temp_Gnum:numof_row %loop in new divided subgroups
            for k=1:numof_subG  %loop in the last divided subgroups
              tempdata=temp(k,:);
              tempdata=tempdata(j:j+temp_Gnum-1); %new sepreation of the groups
              eval(['group',num2str(i),'(idx,:)=tempdata;']); %updata to new group
              idx=idx+1;
            end
        end
        numof_row=temp_Gnum; %number of row in each new subgroup
        numof_subG=idx-1; %number of new subgroups
        eval(['temp=group',num2str(i),';']); %update the temp
        eval(['group{i}=temp;']);
     end
   else %start column data %if 
      temp_Gnum=numof_col/numofGin_X(i) ;%number of elements in each subgroups
      idx=1;
      if isfirst==1
        startnumof_ColGp=i;
        temp=[];
        for j=1:temp_Gnum:numof_col
           temp(:,:,idx)=j:j+temp_Gnum-1;
           eval(['group',num2str(i),'(idx,:)=temp(:,:,idx);']);
           idx=idx+1;
        end
        numof_col=temp_Gnum; %number of col in each subgroups
        eval(['temp=group',num2str(i),';']); %update the temp
        eval(['group{i}=temp;']);
        numof_subG=idx-1; %number of subgroups
        isfirst=0;
      else % start rest of level groups
         
         for j=1:temp_Gnum:numof_col %loop in new divided subgroups
            for k=1:numof_subG  %loop in the last divided subgroups
              tempdata=temp(k,:);
              tempdata=tempdata(j:j+temp_Gnum-1); %new sepreation of the groups
              eval(['group',num2str(i),'(idx,:)=tempdata;']) ;%updata to new group
              idx=idx+1;
            end
        end
        numof_col=temp_Gnum; %number of col in each new subgroup
        numof_subG=idx-1; %number of new subgroups
        eval(['temp=group',num2str(i),';']); %update the temp
        eval(['group{i}=temp;']);
     end %end if in first
   end %end column
end %end all
result.groupidx=group;
if ~isempty(startnumof_ColGp)
    result.startnumof_Col=startnumof_ColGp;
else
     result.startnumof_Col=columnStart;
end
result.numoftype_ineachGp=numofGin_X;
result.orderof_Gp=sread;
result.sizeof_data=size_data;

%test each cell have how many zero entry , if one cell have one zero entrys, then degree of freedom have to -1
%added Nov14.2002, 
for i=1:length(result.orderof_Gp)
   tempCell=testdata(result.groupidx{i});
   isZeroEntry=sum(tempCell==0,2)==1; %test have one zero entry in the cell
   if sum(isZeroEntry)>0
      result.df_minus(i)=1;
   else
      result.df_minus(i)=0;
   end
end

   
   
