% MGraph Toolbox
% Version 3.0beta, Oct. 2006
% 
% Copyright 2002-2006 by
% Junbai Wang
% Contributed files may contain copyrights of their own.
% 
% MGraph Toolbox comes with ABSOLUTELY NO WARRANTY; for details
% see License.txt in the program package. This is free software,
% and you are welcome to redistribute it under certain conditions;
% see License.txt for details.
% 
% 
% MGraph
% 
%        mgraph   this file
%        License.txt   GNU General Public License 
%        Copyright.txt   Copyright notice
%
% mgraph is the directory contains all files.
% MGraph is the function launches MGraph toolbox.

% MGraph is a Matlab toolbox that applies probabilistic graphical modeles for microarray data analysis.
% It contains below main functions: Gaussian Networks, various Gaussian Graphical Models, Graphical Loglinear Models
% and PC algorithm.
%
% Reference:
% 1.) Wang J, Cheung LW, Delabie J.
% New probabilistic graphical models for genetic regulatory networks studies.
% J Biomed Inform. 2005 Dec;38(6):443-55. 
%
% 2.) Wang J, Myklebost O, Hovig E.
% MGraph: graphical models for microarray data analysis.
% Bioinformatics. 2003 Nov 22;19(17):2210-1. 
% 
% Aug. 2002 -- Jul. 2004 Tumor Biology Department, The norwegian radium hospital.
% Sep. 2004 -- Oct. 2006 Biological Science Department, Columbia University. 
% Author: Junbai Wang, Last modified October 2006

