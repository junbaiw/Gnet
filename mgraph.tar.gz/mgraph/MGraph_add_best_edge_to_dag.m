function [G,max_score]=MGraph_add_best_edge_to_dag(d,G,sigma,alpha,L,T0,TL,isordered)
%Input:d, G is a DAG, .., isordered==1 means the input variables are ordered
%Output: G is a DAG,...
global graph_form

[nr nc]=size(d);
u0=median(d);
n=nc;
L=nr;
sigma=nc+2;
alpha=nc+2;
v=ones(1,n);

current_score=(gnt_scoring_uncompleteG(G,sigma,alpha,L,T0,TL,n));

disp('Add edge ...');
max_score=current_score;

while max_score<=current_score 
        %add path to graph
        A=[];
        B=[];
        idx_yes=[];
        new_A=[];
        new_B=[];
        temp_edges={};
        idx=1;
        pscore=[];
        done=0;
        temp_graphs={};
        temp_G=[];
        %clear Z1 Z2 ZZ1 ZZ2 ZZZ
        
     
        [A B]=find(abs(triu(setdiag(G,1)))==0); %potential add edges   
 	    %idx_yes=find(A<B);
	    %new_A=A(idx_yes);
	    %new_B=B(idx_yes);
	    %A=[];B=[];
	    %A=new_A;
	    %B=new_B;

        if isempty(A) break; end
        
	if isordered==2
	%input variable is ordered
        for i=1:length(A);
            %add edge in both direction
            x=A(i);y=B(i);
            tempG=G;
            if (tempG(x,y)==0 & tempG(y,x)==0)
                tempG(x,y)=-1;
                tempG(y,x)=0;
                [color,time,d,f,phi,back_edge]=dfs(tempG);
               % if graph_form==1
               %   cond1= (isempty(back_edge) & isDecomposableG(tempG) );
               % else
                   cond1= isempty(back_edge);
                   %  end
                    
                if cond1
                    temp_graphs{idx}=tempG;
                    pscore(idx) = (gnt_scoring_uncompleteG(tempG,sigma,alpha,L,T0,TL,n));
                    idx=idx+1;
                end
                
                %add reversed edge if it still is DAG
                tempG(x,y)=0;
                tempG(y,x)=-1;
                [color,time,d,f,phi,back_edge]=dfs(tempG);
                 %if graph_form==1
                 % cond1= (isempty(back_edge) & isDecomposableG(tempG) );
                 %else
                   cond1= isempty(back_edge);
                   %end
                    
                if cond1
                    temp_graphs{idx}=tempG;
                    pscore(idx) = (gnt_scoring_uncompleteG(tempG,sigma,alpha,L,T0,TL,n));
                    idx=idx+1;
                end
            end %end if
            
        end %end for
	elseif isordered==1
	 for i=1:length(A);
            %add edge
            x=A(i);y=B(i);
            tempG=G;
            
            if ((tempG(x,y)==0 & tempG(y,x)==0) & x<y)
                tempG(x,y)=-1;
                tempG(y,x)=0;
                
                %if graph_form==1
                %  cond1= (isDecomposableG(tempG) );
                %else
                   cond1= 1;
                   %end
                if cond1
                    temp_graphs{idx}=tempG;
                    pscore(idx) = (gnt_scoring_uncompleteG(tempG,sigma,alpha,L,T0,TL,n));
                    idx=idx+1;
                end
            end %end if
        end %end for
	end
        
        if ~isempty(temp_graphs)
            
            [best_pscore, best_p] = max(pscore);
            best_graph=temp_graphs{best_p};
           
            current_score=best_pscore;
            current_G=best_graph;
            done=1;
        else
            done=1;
        end
        if current_score>max_score
            disp('add edge')
            max_score=current_score;
            G=current_G;
            ischanged=1;
        elseif current_score==max_score & done
            break;
        end
end
