% MGraph Toolbox
% Version 3.0beta, Oct. 2006
%
% Copyright 2002-2006 by
% Junbai Wang
% Contributed files may contain copyrights of their own.
%
% MGraph Toolbox comes with ABSOLUTELY NO WARRANTY; for details
% see License.txt in the program package. This is free software,
% and you are welcome to redistribute it under certain conditions;
% see License.txt for details.
%
%
% MGraph
%
%        mgraph   this file
%        License.txt   GNU General Public License
%        Copyright.txt   Copyright notice
%	
% mgraph is the directory contains all files.
% MGraph is the function launches MGraph toolbox.
%
% MGraph is a Matlab toolbox that applies probabilistic graphical modeles for microarray data analysis.
% It contains below main functions: Gaussian Networks, various Gaussian Graphical Models, Graphical Loglinear Models
% and PC algorithm.
%
% Reference:
% 1.) Wang J, Cheung LW, Delabie J.
% New probabilistic graphical models for genetic regulatory networks studies.
% J Biomed Inform. 2005 Dec;38(6):443-55.
%
% 2.) Wang J, Myklebost O, Hovig E.
% MGraph: graphical models for microarray data analysis.
% Bioinformatics. 2003 Nov 22;19(17):2210-1.
%
% Aug. 2002 -- Jul. 2004 Tumor Biology Department, The norwegian radium hospital.
% Sep. 2004 -- Oct. 2006 Biological Science Department, Columbia University.
% Author: Junbai Wang, Last modified October 2006

close all;
clear all;
fclose all;

warning off;
global init_fig table_fig plot_fig isStat
global openBut1 htxt_cutoffP Brun htxt_RowOrCol RowOrCol_field Normalization_field


isdelete=0; %delecte wel

pscanversion='  3.0';
pscansubversion='.00';
pscanstring = ['MGraph ',pscanversion,pscansubversion];

if (~exist('rerun'));
   ficon = imread('marray_mscan.tif');
	% this creates a messagebox
%   hstr = char('Welcome to Marray Ver 1.2.01',...
%      'Help manual available inside code !');
%    h=msgbox(hstr,pscanstring,'custom',ficon,hot(64));  uiwait(h);
end

init_fig=figure(24);
%table_fig=figure(25);
set(init_fig,'Color',[0.8 1 1], ...
   	'units','normalized', ...
   	'Position',[0.1 0.07 0.45 0.45], ...
   	'DoubleBuffer','on',...
   	'Tag','Inital_fig',...
    'NumberTitle','off',...
    'Name','MGraph');

%set(table_fig,'Color',[0.8 1 1], ...
%   	'units','normalized', ...
%   	'Position',[0.55 0.07 0.3 0.45], ...
%   	'DoubleBuffer','on',...
%   	'Tag','table_fig',...
%    'NumberTitle','off',...
%    'Name','Marray -Debug');



%'MenuBar','none',...
ficonaxes = axes('Parent',init_fig, ...
		 'units','normalized', ...
		 'CameraUpVector',[0 1 0], ...
		 'CameraUpVectorMode','manual', ...
		 'Color',[1 1 1], ...
		 'Position',[0.2 .2 .5 .50], ...
		 'Tag','Inital_fig_axes', ...
		 'XColor',[0 0 0], ...
		 'YColor',[0 0 0], ...
		 'ZColor',[0 0 0],...
         'XTick',[],...
         'YTick',[]');
axes(ficonaxes);
image(ficon);
axis off;

ficonmessagesbg = uicontrol('Parent',init_fig, ...
			'Units','normalized',  ...
			'Position',[0.1,0.72,0.8,0.1], ...
			'String','Welcome to MGraph Ver 3.0!', ...
			'Style','text', ...
			'BackgroundColor',[1 1 1], ...
			'fontweight','bold', ...
			'fontname','Helvetica', ...
			'fontunits', 'normalized', ...   
			'fontsize', .4, ...
			'Tag','Inital_fig_message');
        
  fmenu=uimenu('Label','MGraph');
      uimenu(fmenu,'Label','MGraph Properties','Callback','MGraph_properties');
	   uimenu(fmenu,'Label','Graphical logline model','Callback',['MGraph_logline;']);
   	   uimenu(fmenu,'Label','Graphical gaussion model','Callback',[ 'MGraph_gauss;']);
       uimenu(fmenu,'Label','Quit','Callback',['clear all;close all hidden'],...
           'Separator','on','Accelerator','Q');
    dmenu=uimenu('Label','MGraph Debug'); 
    uimenu(dmenu,'Label','MGraph Debug','Callback','marray_debug'); 

set(init_fig,'HandleVisibility','on');
