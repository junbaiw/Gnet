function needtestEG=MGraph_loglineOutput2(out,OldneedtestEG)
global graph_form

lnofvar=length(out.numoftype_ineachGp);
rem_idx=1;
idx=1;
removeEG.P=0;
edge_df=[];
edge_name=[];
edge_device=[];
edge_P=0;
edge_Pmark=0;
edge_isSDordering=[] ;%added sep 2006
%above is the initial values

string_name=sort(out.labelof_Gp); %out.labelof_Gp(out.orderof_Gp); %reorder the string as ABCDEF.....
%because in the out results, the device is arranged as ABCDEF.. order in the matrise

for i=1:lnofvar-1 %only select low part of matrise
      for j=i+1:lnofvar
        temp_device=out.device(j,i);
        temp_df=out.df(j,i); %bug at here nov12.2002-out.df_minus(j)-out.df_minus(i); %remove one df if one entry of cell is zero;
        temp_P=Chisq(temp_device,temp_df); %Chi squr test
        
        %added 12.05 for test decomposiable model
        %make new subgroup
        delet_edge_location=[j,i];
        %delet_edge_location=[6 1 ];
        %delet_edge_string=MGraph_num2string(delet_edge_location)
        delet_edge_string=cellstr(string_name(delet_edge_location));
        temp_newModel=sort(cellstr(out.new_model)); %possibile bug at here
        %temp_newModel=sort({'ADE','ACE','ABC','ABF'});
        new_model=MGraph_makeSubGraph(temp_newModel,delet_edge_string);
        clear numberVector
        for new_idx=1:length(new_model)
          		numberVector{new_idx}=num2str(MGraph_string2num(new_model(new_idx)));
        end
        input_k_cliques=(numberVector)';
          
        if graph_form==1 %decomposable modle
         		 is_SDordering=MGraph_isSDordering(input_k_cliques);
        elseif graph_form==2
                is_SDordering=1;
        else
             error('Please select graphical model in ''MGraph properties''!, Program stop!');
             break;
        end    
        edge_isSDordering(idx)=is_SDordering;
        %end added 12.05

        
        if (temp_P>=out.cutoff_P )
            temp_string{idx}=sprintf(['[',string_name(j),'', string_name(i),'] Dev=',num2str(temp_device)...
                ,' Df=',num2str(temp_df),' P=',num2str(temp_P)]);
            %display string
            %needremove_edge_name{idx}=sprintf(['[',string_name(j),'', string_name(i),'] ']);
            %needremove_edge_df(idx)=temp_df;
            %needremove_edge_device(idx)=temp_device;
            %needremove_edge_P(idx)=temp_P;
            %needremove_edge_Pmark(idx)=1; %P>=cutoff
            
            %added 12.03, in conherance step only edge exist in the oldest needtestEdge need be test 
            temp_edge_name1=sprintf(['[',string_name(j),'', string_name(i),']']);
            temp_edge_name2=sprintf(['[',string_name(i),'', string_name(j),']']);
            if (ismember(temp_edge_name1,OldneedtestEG.allname) | ismember(temp_edge_name2,OldneedtestEG.allname))
            	edge_name{idx}=sprintf(['[',string_name(j),'', string_name(i),']']);
            	edge_df(idx)=temp_df;
            	edge_device(idx)=temp_device;
            	edge_P(idx)=temp_P;
              edge_Pmark(idx)=1; %P>=cutoff
              idx=idx+1;   
            end
            %end add   
        else  %added 12.03, in conherance step only edge exist in the oldest needtestEdge need be test
            temp_edge_name1=sprintf(['[',string_name(j),'', string_name(i),']']);
            temp_edge_name2=sprintf(['[',string_name(i),'', string_name(j),']']);
            if (ismember(temp_edge_name1,OldneedtestEG.allname) | ismember(temp_edge_name2,OldneedtestEG.allname))
                temp_string{idx}=sprintf(['[',string_name(j),'', string_name(i),'] Dev=',num2str(temp_device)...
                ,' Df=',num2str(temp_df),' P=',num2str(temp_P),' +']);        
                edge_name{idx}=sprintf(['[',string_name(j),'', string_name(i),'] ']);
            	edge_df(idx)=temp_df;
            	edge_device(idx)=temp_device;
            	edge_P(idx)=temp_P;
                edge_Pmark(idx)=0; %P>=cutoff
                idx=idx+1;
            end %end add 12.03
        end
       
    end
end
temp_string{idx}=['Model: ', string_name];
%strvcat(temp_string) ;%display output results
marray_debuge(strvcat(temp_string));

needtestEG.model=string_name;
needtestEG.edge_name=edge_name;

needtestEG.edge_df=edge_df;
needtestEG.edge_device=edge_device;
needtestEG.edge_P=edge_P;
needtestEG.disp_string=temp_string;
needtestEG.edge_Pmark=edge_Pmark;
%add 12.05
needtestEG.edge_isSDordering=edge_isSDordering;    