function gp2_idxgp=MGraph_loglineSortIdxgp(row_gp2,gp2,rb)
    idx=1;
    interval=row_gp2/rb;
    for i=1:interval:row_gp2
        tmp_size=size(gp2(i:i+interval-1,:));
        gp2_idxgp{idx}=reshape(sortrows(gp2(i:i+interval-1,:))',tmp_size(1)*tmp_size(2),1);
        idx=idx+1;
    end