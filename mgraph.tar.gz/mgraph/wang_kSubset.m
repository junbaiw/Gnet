function ksubset=wang_kSubset(nb,k)
%Generate the subsets of a sets nb with k elements
%
clear in out
global m2 h

%n=20
%k=5
n=length(nb);
mtc=0;
in=zeros(1,n);
idx=0;
[in,mtc]=wang_nexksb(n,k,in,mtc);
idx=1;
out(idx,:)=in(1:k);
if mtc
    while mtc
        idx=idx+1;
        [in ,mtc]=wang_nexksb(n,k,in,mtc);
        out(idx,:)=in(1:k);
        
    end
end
if k==0
    ksubset={[]};    
else
    ksubsets=nb(out);
    s_ksub=prod(size(ksubsets));
    ksubset=reshape(ksubsets,s_ksub/k,k);
end    