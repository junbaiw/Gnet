function MGraph_export2Pjart(filename,varnames,spareM,old_parcorrf)
%
%export data to Pajrt

idx_dot=findstr('.',filename);
outfile=[filename(1:idx_dot-1)];
fid=fopen(outfile,'w');
len_of_nodes=size(varnames,1);
fprintf(fid,'%s %s \n','*Vertices  ',num2str(len_of_nodes));
for i=1:len_of_nodes
      fprintf(fid,'%s %s \n',num2str(i),['"',deblank(strvcat(varnames(i,:))),'"']);
end
fprintf(fid,'%s\n','*Arcs  ');

[xx yy]=find(abs(spareM)==1);
len_xx=length(xx);
for i=1:len_xx
	if abs(old_parcorrf(xx(i),yy(i)))<0.000001
		temp_corrf=0.000001;
	else
		temp_corrf=old_parcorrf(xx(i),yy(i));
	end
     fprintf(fid,'%s  \n',[num2str(xx(i)),' ',num2str(yy(i)),' ',num2str(temp_corrf),' ap'] );
end
fclose(fid);
