function condP=gnt_scoring_uncompleteG(c,sigma,alpha,L,T0,TL,n);
%
%Input: c is the network structure, sigma and alpha is effective sample size of mean and the variance,
%L is case numberm T0 and TL is initial and estimated precise matrix
%
%Output: conditional density of input network structure
%

%len_c=length(c);
%vertice_and_parients={};
%parients={};
%for i=1:len_c
%    %find each vertice's parients
%    if i>1
%        temp_c_parients=c{i};
%        %find parents
%        idx_p=find(temp_c_parients==1);
%        if ~isempty(idx_p)
%            parients{i}=idx_p;
%            vertice_and_parients{i}=[i,parients{i}];
%        else
%            parients{i}=[];
%            vertice_and_parients{i}=[i,parients{i}];
%        end
%    else
%        parients{i}=[];
%        vertice_and_parients{i}=[i,parients{i}];
%        %its the root
%    end
%end

%find vertices and its parients
len_c=size(c,1);
parients={};
vertice_and_parients={};
for i=1:len_c
    pari=find(c(:,i))';
    parients{i}=pari;
    vertice_and_parients{i}=sort([i,parients{i}]);
end

%compute uncomplete the network
%condP=1;
%for i=1:len_c
%    v_and_p=vertice_and_parients{i};
%    pari=parients{i};
%    cond_density_vp=gnt_conditional_density(length(v_and_p),L,sigma,alpha,T0(v_and_p,v_and_p),TL(v_and_p,v_and_p));
%    cond_density_pa=gnt_conditional_density(length(pari),L,sigma,alpha,T0(pari,pari),TL(pari,pari));
%    condP=condP*cond_density_vp/cond_density_pa;
%end

condP=0;
for i=1:len_c
    v_and_p=vertice_and_parients{i};
    pari=parients{i};
    cond_density_vp=gnt_conditional_density(length(v_and_p),L,sigma,alpha,T0(v_and_p,v_and_p),TL(v_and_p,v_and_p));
    cond_density_pa=gnt_conditional_density(length(pari),L,sigma,alpha,T0(pari,pari),TL(pari,pari));
    condP=condP+cond_density_vp-cond_density_pa;
end
%add jbw 10 2004
%tempG=c;
%mod_d=sum(sum(abs(tempG)));
%mod_r=n;
%mod_n=L;
%add one penitent for model size 
%condP=condP-1/2*mod_d*log10(mod_n);

%end add
