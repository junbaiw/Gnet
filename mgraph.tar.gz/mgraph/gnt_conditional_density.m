function cond_density=gnt_conditional_density(n,L,sigma,alpha,T0,TL)
%compute the conditional density based on the network structure
%
%cond_density=(2*pi)^(-(n*L)/2)*(sigma/(sigma+L))^(n/2)*gnt_C(n,alpha)/gnt_C(n,alpha+L)*det(T0)^(alpha/2)*det(TL)^(-(alpha+L)/2);
%cond_density=(cond_density);
cond_density1=-log10(2*pi)*(n*L/2)+ log10(sigma)*(n/2)-log10(sigma+L)*(n/2);
cond_density2=(gnt_C(n,alpha));
cond_density3=(gnt_C(n,alpha+L));
cond_density4=log10(det(T0))*(alpha/2);
cond_density5=-log10(det(TL))*((alpha+L)/2);
cond_density=cond_density1+cond_density2-cond_density3+cond_density4+cond_density5;
