function isundirected=MGraph_isundirected(G)
%check whether the input G is undirected graph

ug=triu(G);
lg=tril(G);

[la lb]=find(lg);
temp_lg=zeros(size(G));
for i=1:length(la)
    temp_lg(lb(i),la(i))=1;
end

isundirected=sum(sum(abs(ug)-temp_lg))==0;

