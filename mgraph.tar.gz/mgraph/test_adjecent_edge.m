function [diffV ,adjecentV,record_idx]=test_adjecent_edge(len_of_vertices,new_model,add_edge1,visited_idx,add_edge2)
%find adjecent edge of add_edge1 in new_model
%
diffV=add_edge1;
adjecentV=[];
record_idx=-1;
idx_reco=1;
for i=1:len_of_vertices
    if ~ismember(i,visited_idx)
        %try find the path
        intersectV=intersect(new_model{i},add_edge1);
        if (~isempty(intersectV) )
            diffV=setdiff(new_model{i},diffV);
            %if ismember(add_edge2,diffV)
            if isempty(diffV)
                diffV=-1;
            end
            record_idx(idx_reco)=i;
            adjecentV{idx_reco}=intersectV;
            idx_reco=idx_reco+1;
        end
    end
end
