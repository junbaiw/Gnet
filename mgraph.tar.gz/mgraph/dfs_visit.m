function [color,time,d,f,phi,idx,back_edge]=dfs_visit(G,u,color,time,d,f,phi,idx,back_edge)
%it is for directed graph
color(u)=1 ;%white i just been discovered and assign gray color 1
time=time+1;
d(u)=time;
v=children(G,u);
len_of_v=length(v);

for j=1:len_of_v
    if color(v(j))==0
        %tree edge
        phi{v(j)}=setdiff(union(u,phi{v(j)}),-1);
        [color,time,d,f,phi,idx,back_edge]=dfs_visit(G,v(j),color,time,d,f,phi,idx,back_edge);
    elseif color(v(j))==1
        %back edge
        back_edge{idx}=[u v(j)];
        idx=idx+1;
    end
end
color(u)=2 ;%black 2 it is finish
time=time+1;
f(u)=time;

